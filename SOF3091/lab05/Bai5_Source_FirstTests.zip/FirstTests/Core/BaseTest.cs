using FirstTests.Config;
using FirstTests.Utilities;
using NUnit.Framework.Interfaces;
using OpenQA.Selenium;

namespace FirstTests.Core;

public abstract class BaseTest
{
    protected IWebDriver driver = null!;
    protected TestConfig cfg    = null!;

    [SetUp]
    public void BaseSetup()
    {
        cfg    = ConfigReader.Load();
        driver = DriverFactory.Create(cfg);
        // KHÔNG gọi Maximize(): ở headless nó vô nghĩa.
        // Kích thước đã đặt bằng --window-size trong DriverFactory -> headed & headless giống nhau.
        driver.Navigate().GoToUrl(cfg.BaseUrl);
    }

    [TearDown]
    public void BaseTearDown()
    {
        try
        {
            if (TestContext.CurrentContext.Result.Outcome.Status == TestStatus.Failed)
                ScreenshotHelper.Chup(driver);
        }
        finally
        {
            // finally: chụp ảnh lỗi cũng KHÔNG được ngăn việc đóng trình duyệt
            driver?.Quit();
            driver?.Dispose();
        }
    }
}